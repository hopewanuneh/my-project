<footer class="footer">
        <div class="bottom-links">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Contact Us</a>
        </div>
        <p>&copy; 2024 Mortuary Management System</p>
    </footer>
</body>
</html>